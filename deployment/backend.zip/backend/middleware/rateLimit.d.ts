import { Request, Response, NextFunction } from 'express';
export declare const rateLimitConfig: (req: Request, res: Response, next: NextFunction) => Promise<void>;
//# sourceMappingURL=rateLimit.d.ts.map